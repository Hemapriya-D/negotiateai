# NegotiateAI: A Multimodal AI System for Automated Negotiation

Prototype built from the project report. Stack (Table 3.2, "Prototype" column):
**React + TypeScript + Vite** frontend, **Python + FastAPI** backend, **Gemini API** model, **SQLite** storage, run **locally**.

## Run it

### 1. Backend (port 8000)
```bash
cd backend
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                    # then paste your GEMINI_API_KEY
uvicorn main:app --reload --port 8000
```
Without a key the app still works in **offline demo mode** (template messages, basic number detection).
The limit guard, scoring, strategy picker and simulated counterparty are ordinary code and run the same either way.

### 2. Frontend (port 5173)
```bash
cd frontend
npm install
npm run dev
```
Open http://localhost:5173 and click **View Demo** (the house-rent example from the screenshots).

## What maps to the report
| Report section | Where |
|---|---|
| 3.6 Multimodal input (text, forms, documents, images; uncertain fields flagged) | `backend/llm.py` `extract`, `POST /api/extract`, form buttons in `NewNegotiation.tsx` |
| Voice input (screenshots; report lists it as future work) | Browser speech recognition in `frontend/src/speech.ts` (Chrome/Edge) |
| 3.7 Domain profiles + offer scoring, Eq. 3.1 | `backend/engine.py` `PROFILES`, `score` |
| 3.8 Strategy picker, Table 3.5, Eq. 3.2 and 3.3 | `engine.py` `pick_strategy`, `target_score`, `read_counterparty` |
| 3.9 Offer generator + limit guard (retry up to 3, then safest offer / walk away) | `negotiation.py` `produce_offer`, `engine.py` `guard` |
| 3.10 Negotiation loop + deal tracker (sessions, messages, offers, deals) | `negotiation.py`, `db.py` |
| Assist / autonomous modes, user approval before any deal closes | `Workspace.tsx`, `negotiation.decide` |
| Planned evaluation: stubborn / flexible / random simulated counterparties | `engine.py` `sim_*` |

## Notes
- **Continuous negotiation:** in Autonomous mode the Workspace keeps running rounds (offer, counter-offer, response) until the counterparty's offer meets your target score (you then approve), the deadline passes (walk away), or you pause.
- **Counterparty:** simulated (stubborn / flexible / random) or **Manual**, where you type or speak the other side's replies.
- Home-page numbers are live from your local database. They are not marketing claims; the report says no experimental results exist yet.
- Report items marked as *planned production* (AWS, Docker, CI/CD, Redis, Pinecone, LangChain, WebSocket, Node.js gateway, live market data) are intentionally not included.
- The β values and rule-based picker are starting points, as stated in the report.
