"""SQLite storage used by the deal tracker (report Table 3.7: sessions, messages, offers, deals)."""
import json, os, sqlite3, time

DB_PATH = os.getenv("NEGOTIATEAI_DB", os.path.join(os.path.dirname(os.path.abspath(__file__)), "negotiateai.db"))

SCHEMA = """
CREATE TABLE IF NOT EXISTS sessions(
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, domain TEXT, context TEXT, counterparty TEXT,
  currency TEXT, ask REAL, target REAL, limit_price REAL, rounds_total INTEGER, mode TEXT, cp_type TEXT,
  weights TEXT, state TEXT, status TEXT, round INTEGER DEFAULT 0, created_at REAL);
CREATE TABLE IF NOT EXISTS messages(
  id INTEGER PRIMARY KEY AUTOINCREMENT, session_id INTEGER, round INTEGER, role TEXT, text TEXT, created_at REAL);
CREATE TABLE IF NOT EXISTS offers(
  id INTEGER PRIMARY KEY AUTOINCREMENT, session_id INTEGER, round INTEGER, side TEXT, price REAL, fallback_price REAL,
  strategy TEXT, score REAL, target_score REAL, status TEXT, reason TEXT, created_at REAL);
CREATE TABLE IF NOT EXISTS deals(
  session_id INTEGER PRIMARY KEY, outcome TEXT, price REAL, saved REAL, rounds INTEGER, closed_at REAL);
"""


def conn():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    return c


def init():
    with conn() as c:
        c.executescript(SCHEMA)


def _rows(sql, args=()):
    with conn() as c:
        return [dict(r) for r in c.execute(sql, args).fetchall()]


def _exec(sql, args=()):
    with conn() as c:
        return c.execute(sql, args).lastrowid


def _session(row):
    s = dict(row)
    s["limit"] = s.pop("limit_price")
    s["weights"] = json.loads(s["weights"] or "{}")
    s["state"] = json.loads(s["state"] or "{}")
    return s


def create_session(d, weights, state):
    return _exec(
        "INSERT INTO sessions(name,domain,context,counterparty,currency,ask,target,limit_price,rounds_total,mode,cp_type,weights,state,status,round,created_at)"
        " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (d["name"], d["domain"], d["context"], d["counterparty"], d["currency"], d["ask"], d["target"], d["limit"],
         d["rounds_total"], d["mode"], d["cp_type"], json.dumps(weights), json.dumps(state), "active", 0, time.time()))


def get_session(sid):
    rows = _rows("SELECT * FROM sessions WHERE id=?", (sid,))
    return _session(rows[0]) if rows else None


def list_sessions():
    out = []
    for r in _rows("SELECT * FROM sessions ORDER BY id DESC"):
        s = _session(r)
        deal = _rows("SELECT * FROM deals WHERE session_id=?", (s["id"],))
        s["deal"] = deal[0] if deal else None
        out.append(s)
    return out


def update_session(sid, **f):
    cols, vals = [], []
    for k, v in f.items():
        if k in ("state", "weights"):
            v = json.dumps(v)
        if k == "limit":
            k = "limit_price"
        cols.append(f"{k}=?")
        vals.append(v)
    _exec(f"UPDATE sessions SET {','.join(cols)} WHERE id=?", (*vals, sid))


def add_message(sid, rnd, role, text):
    _exec("INSERT INTO messages(session_id,round,role,text,created_at) VALUES(?,?,?,?,?)", (sid, rnd, role, text, time.time()))


def add_offer(sid, rnd, side, price, fallback, strategy, score, target_score, status, reason):
    _exec("INSERT INTO offers(session_id,round,side,price,fallback_price,strategy,score,target_score,status,reason,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
          (sid, rnd, side, price, fallback, strategy, score, target_score, status, reason, time.time()))


def messages(sid):
    return _rows("SELECT * FROM messages WHERE session_id=? ORDER BY id", (sid,))


def offers(sid):
    return _rows("SELECT * FROM offers WHERE session_id=? ORDER BY id", (sid,))


def set_deal(sid, outcome, price, saved, rounds):
    _exec("INSERT OR REPLACE INTO deals(session_id,outcome,price,saved,rounds,closed_at) VALUES(?,?,?,?,?,?)",
          (sid, outcome, price, saved, rounds, time.time()))


def stats():
    deals = _rows("SELECT outcome, COUNT(*) n, COALESCE(SUM(price),0) value, COALESCE(AVG(rounds),0) rounds, COALESCE(SUM(saved),0) saved FROM deals GROUP BY outcome")
    by = {d["outcome"]: d for d in deals}
    closed, walked = by.get("deal", {}), by.get("walk_away", {})
    n_closed, n_walk = closed.get("n", 0), walked.get("n", 0)
    return {
        "sessions": _rows("SELECT COUNT(*) n FROM sessions")[0]["n"],
        "deals_closed": n_closed, "walk_aways": n_walk,
        "value_negotiated": closed.get("value", 0), "total_saved": closed.get("saved", 0),
        "avg_rounds": closed.get("rounds", 0),
        "success_rate": round(100 * n_closed / (n_closed + n_walk)) if (n_closed + n_walk) else 0,
        "blocked_drafts": _rows("SELECT COUNT(*) n FROM offers WHERE status='blocked'")[0]["n"],
        "by_domain": _rows("SELECT domain, COUNT(*) n FROM sessions GROUP BY domain"),
    }
