"""Shared negotiation engine (no I/O): domain profiles, offer scoring (Eq 3.1), strategy picker,
time-dependent target score (Eq 3.2), counterparty reading (Eq 3.3), limit guard and a simulated counterparty."""
import random
import re

PROFILES = {
    "pricing": {"label": "Pricing", "icon": "💰", "blurb": "Negotiate product & service pricing with precision",
                "issues": ["Price", "Discount", "Quantity", "Payment terms"], "hard_limit": "Lowest selling price",
                "w": {"c": .45, "t": .15, "r": .20, "s": .20}},
    "vendor": {"label": "Vendor", "icon": "🤝", "blurb": "Secure the best vendor contracts and partnerships",
               "issues": ["Unit price", "Delivery time", "Warranty", "Payment period"], "hard_limit": "Highest budget per unit",
               "w": {"c": .40, "t": .25, "r": .20, "s": .15}},
    "hiring": {"label": "Hiring", "icon": "💼", "blurb": "Optimize salary packages and employment terms",
               "issues": ["Salary", "Joining date", "Benefits", "Notice period"], "hard_limit": "Salary cap or floor",
               "w": {"c": .35, "t": .15, "r": .30, "s": .20}},
    "retention": {"label": "Retention", "icon": "🔄", "blurb": "Retain top talent with data-driven counteroffers",
                  "issues": ["Discount", "Plan length", "Extra benefits"], "hard_limit": "Maximum discount",
                  "w": {"c": .30, "t": .10, "r": .40, "s": .20}},
    "custom": {"label": "Custom Builder", "icon": "🛠️", "blurb": "Build any negotiation scenario with full control",
               "issues": ["Issues chosen by the user"], "hard_limit": "Limits set by the user",
               "w": {"c": .25, "t": .25, "r": .25, "s": .25}},
}

# Table 3.5
STRATEGIES = {
    "collaborative": {"beta": 2.0, "tone": "Warm, open to tradeoffs"},
    "compromise": {"beta": 1.0, "tone": "Neutral, steady"},
    "competitive": {"beta": 0.4, "tone": "Firm, brief"},
}


def clamp(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))


def validate(ask, target, limit):
    if ask == target:
        return "Your target must differ from their opening ask."
    d = 1 if target < ask else -1
    if d * (limit - target) < 0:
        return "Walk-away limit must be on the weaker side of your target (a buyer's limit is above the target, a seller's is below it)."
    return None


def make_ctx(s):
    ask, target, limit = float(s["ask"]), float(s["target"]), float(s["limit"])
    w = dict(s.get("weights") or PROFILES.get(s["domain"], PROFILES["custom"])["w"])
    tot = sum(w.values()) or 1.0
    w = {k: v / tot for k, v in w.items()}
    return {"ask": ask, "target": target, "limit": limit, "T": int(s["rounds_total"]), "w": w,
            "dir": 1 if target < ask else -1, "g0": abs(ask - target) or 1.0}


def money(c, p):
    p = round(p) if max(abs(c["ask"]), abs(c["target"])) >= 100 else round(p, 2)
    return p


def fmt(cur, p):
    return f"{cur}{p:,.0f}" if abs(p) >= 100 else f"{cur}{p:,.2f}"


# ---------- Eq 3.1: S(o) = sum_k w_k u_k(o) ----------
def util(c, p, r, their_last, neutral=False):
    span = c["target"] - c["limit"]
    uc = clamp((p - c["limit"]) / span) if span else 1.0          # 1 at target, 0 at walk-away limit
    ut = 1 - r / c["T"]                                            # earlier closing is better
    if neutral:                                                     # scoring the counterparty's own proposal
        ur = us = 0.5
    else:
        g = abs(p - their_last) / c["g0"]
        ur = 1 - clamp(g)                                           # closer to them keeps the relationship warm
        us = 1 - clamp(0.5 * g + 0.5 * r / c["T"])                  # safety = 1 - risk the deal falls through
    return {"c": uc, "t": ut, "r": ur, "s": us}


def score(c, p, r, their_last, neutral=False):
    u = util(c, p, r, their_last, neutral)
    return sum(c["w"][k] * u[k] for k in u), u


def a_min(c, their_last=None, neutral=False):
    """Lowest score the user would accept: the walk-away offer at the deadline (Section 3.7)."""
    return score(c, c["limit"], c["T"], c["ask"] if their_last is None else their_last, neutral)[0]


def a_0(c, their_last=None, neutral=False):
    return score(c, c["target"], 0, c["ask"] if their_last is None else their_last, neutral)[0]


# ---------- Eq 3.2: A(t) = Amin + (A0 - Amin)[1 - (t/T)^(1/beta)] ----------
def target_score(c, r, beta, their_last=None, neutral=False):
    """The end points are scored against the counterparty's latest offer, so the concession schedule always spans
    the scores that are actually reachable in the current situation."""
    lo, hi = a_min(c, their_last, neutral), a_0(c, their_last, neutral)
    return lo + (hi - lo) * (1 - min(1.0, r / c["T"]) ** (1 / beta))


def pick_price(c, r, their_last, A, prev_our):
    """Offer generator: the price whose score S(o) is closest to A(t), never retreating and never crossing the other side."""
    best = None
    for i in range(401):
        p = c["target"] + (c["limit"] - c["target"]) * i / 400
        d = abs(score(c, p, r, their_last)[0] - A)
        if best is None or d < best[0]:
            best = (d, p)
    p = best[1]
    if prev_our is not None and c["dir"] * (p - prev_our) < 0:
        p = prev_our
    if c["dir"] * (p - their_last) > 0:
        p = their_last
    p = money(c, p)
    return c["limit"] if c["dir"] * (p - c["limit"]) > 0 else p


def fallback_price(c, price, their_last):
    """A second offer a little closer to the counterparty (a trade of one issue for another), still inside the limit."""
    fb = money(c, price + 0.3 * (their_last - price))
    return c["limit"] if c["dir"] * (fb - c["limit"]) > 0 else fb


# ---------- Strategy picker (rule based) ----------
def pick_strategy(c, r, our_last, their_last, rho=None):
    t_share = (r - 1) / c["T"]
    gap = 1.0 if our_last is None else abs(our_last - their_last) / c["g0"]
    stubborn = rho is not None and r > 1 and rho < t_share
    if c["w"]["r"] >= 0.35 and gap < 0.3:
        style, why = "collaborative", "Relationship weight is high and the gap is small."
    elif t_share >= 0.6 or 0.3 <= gap < 0.6 or (stubborn and t_share >= 0.5):
        style, why = "compromise", "The deadline is near or the gap is medium."
        if stubborn:
            why = "The counterparty is moving slower than the clock and the deadline is close."
    else:
        style, why = "competitive", "Many rounds are left and there is little movement from the other side."
    return {"style": style, "beta": STRATEGIES[style]["beta"], "tone": STRATEGIES[style]["tone"], "reason": why}


# ---------- Eq 3.3: rho(t) = (G0 - Gt) / G0 ----------
def read_counterparty(c, first_our, our_last, their_last, r):
    gap0 = abs(c["ask"] - first_our) or 1.0
    rho = clamp((gap0 - abs(their_last - our_last)) / gap0, -1, 1)
    share = r / c["T"]
    label = "stubborn" if rho < share - 0.02 else "flexible" if rho > share + 0.02 else "steady"
    return {"rho": rho, "label": label}


# ---------- Limit guard (ordinary code, outside the LLM) ----------
def leaks(message, limit):
    for m in re.findall(r"\d[\d,]*(?:\.\d+)?", message or ""):
        try:
            if abs(float(m.replace(",", "")) - limit) < 1e-6:
                return True
        except ValueError:
            pass
    return False


def within_limit(c, p):
    return p is not None and p > 0 and c["dir"] * (p - c["limit"]) <= 0


def guard(c, p, r, their_last, message=None):
    if p is None or p <= 0:
        return False, "the draft has no valid price"
    if not within_limit(c, p):
        return False, "the offer is beyond the walk-away limit"
    if score(c, p, r, their_last)[0] < a_min(c) - 1e-9:
        return False, "the offer score is below A_min"
    if message and abs(p - c["limit"]) > 1e-9 and leaks(message, c["limit"]):
        return False, "the message reveals the walk-away limit"
    return True, "passed"


def acceptable(c, price, r, A, our_last):
    """Should the counterparty's offer go to the user for approval?"""
    if not within_limit(c, price):
        return False
    if our_last is not None and c["dir"] * (price - our_last) <= 0:
        return True
    return score(c, price, r, price, neutral=True)[0] >= A


# ---------- Simulated counterparty (stubborn / flexible / random) ----------
def sim_params(cp_type, c, rng):
    if cp_type == "stubborn":
        f, beta = 0.9, 0.4
    elif cp_type == "flexible":
        f, beta = 0.45, 2.0
    else:
        f, beta = rng.uniform(.2, 1.15), rng.uniform(.4, 2.0)
    return {"reserve": c["target"] + f * (c["limit"] - c["target"]), "beta": beta, "noise": 0.02 if cp_type == "random" else 0.0}


def sim_offer(c, cp, r, our_price, prev, seed):
    frac = min(1.0, r / c["T"]) ** (1 / cp["beta"])
    price = c["ask"] + (cp["reserve"] - c["ask"]) * frac
    if cp["noise"]:
        price += random.Random(seed * 100 + r).uniform(-1, 1) * cp["noise"] * c["g0"]
    price = money(c, price)
    if c["dir"] * (price - prev) > 0:      # a counterparty never takes back a concession
        price = prev
    return price, c["dir"] * (our_price - price) >= 0


def sim_message(cp_type, cur, price, accepted, r, T):
    p = fmt(cur, price)
    if accepted:
        return f"That works for me. We have a deal at {p}."
    if r >= T:
        return f"This is my final position: {p}."
    if cp_type == "stubborn":
        return f"I can't go that low. {p} is the best I can do right now."
    if cp_type == "flexible":
        return f"I'd like to find a middle ground. How about {p}?"
    return f"Let me think about it... {p} is where I am."
