"""NegotiateAI FastAPI backend: REST API over the shared engine."""
import mimetypes, os, random
from typing import List, Optional

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

import db, engine, llm, negotiation

try:  # optional .env support without extra dependencies
    for line in open(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")):
        if "=" in line and not line.startswith("#"):
            k, v = line.strip().split("=", 1)
            if v:
                os.environ.setdefault(k, v)
except OSError:
    pass

app = FastAPI(title="NegotiateAI")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
db.init()


class Setup(BaseModel):
    name: str = "Untitled negotiation"
    domain: str = "custom"
    context: str = ""
    counterparty: str = "Counterparty"
    ask: float
    target: float
    limit: float
    currency: str = "₹"
    rounds_total: int = Field(6, ge=2, le=12)
    mode: str = "autonomous"
    cp_type: str = "stubborn"
    weights: Optional[dict] = None


class Settings(BaseModel):
    mode: Optional[str] = None
    cp_type: Optional[str] = None
    rounds_total: Optional[int] = Field(None, ge=2, le=12)


def _check(setup: Setup):
    if setup.domain not in engine.PROFILES:
        raise HTTPException(422, "Unknown domain.")
    err = engine.validate(setup.ask, setup.target, setup.limit)
    if err:
        raise HTTPException(422, err)


def _out(s):
    c = engine.make_ctx(s)
    st = {k: v for k, v in s["state"].items() if k not in ("cp", "seed")}   # never expose the simulator's hidden reserve
    st.update(amin=engine.a_min(c), a0=engine.a_0(c), dir=c["dir"])
    return {**s, "state": st, "weights": c["w"]}


def _get(sid):
    s = db.get_session(sid)
    if not s:
        raise HTTPException(404, "Negotiation not found.")
    return s


def _run(fn, *a):
    try:
        return _out(fn(*a))
    except ValueError as e:
        raise HTTPException(409, str(e))


@app.get("/api/domains")
def domains():
    return PROFILES_OUT


PROFILES_OUT = {k: {kk: vv for kk, vv in v.items()} for k, v in engine.PROFILES.items()}


@app.get("/api/stats")
def stats():
    return {**db.stats(), "ai": "gemini" if llm.available() else "offline-demo"}


@app.post("/api/extract")
async def extract(text: str = Form(""), domain: str = Form("custom"), files: List[UploadFile] = File(default=[])):
    """Multimodal input processor: text + documents/images -> negotiation fields (uncertain ones are flagged for the user)."""
    blobs = []
    for f in files:
        data = await f.read()
        mime = f.content_type or mimetypes.guess_type(f.filename or "")[0] or "application/octet-stream"
        blobs.append((mime, data))
    res = llm.extract(text, blobs)
    if res:
        return {**res, "source": "gemini"}
    import re
    nums = sorted({float(n.replace(",", "")) for n in re.findall(r"\d[\d,]{2,}", text)}, reverse=True)
    out = {"scenario_name": None, "domain": domain, "context": None, "counterparty": None, "their_opening_ask": nums[0] if nums else None,
           "your_target": nums[-1] if len(nums) > 1 else None, "walk_away_limit": None, "currency": "₹", "source": "offline",
           "uncertain": ["their_opening_ask", "your_target", "walk_away_limit"]}
    return out


@app.post("/api/preview")
def preview(setup: Setup):
    _check(setup)
    c = engine.make_ctx(setup.model_dump() | {"weights": setup.weights or engine.PROFILES[setup.domain]["w"]})
    strat = engine.pick_strategy(c, 1, None, c["ask"])
    A = engine.target_score(c, 1, strat["beta"])
    return {"strategy": strat, "opening_price": engine.pick_price(c, 1, c["ask"], A, None), "a0": engine.a_0(c), "amin": engine.a_min(c),
            "dir": c["dir"], "weights": c["w"], "hard_limit": engine.PROFILES[setup.domain]["hard_limit"]}


@app.post("/api/sessions")
def create(setup: Setup):
    _check(setup)
    d = setup.model_dump()
    weights = setup.weights or engine.PROFILES[setup.domain]["w"]
    c = engine.make_ctx({**d, "weights": weights})
    seed = random.randint(1, 10**6)
    sid = db.create_session(d, weights, negotiation.new_state(c, setup.cp_type, seed))
    db.add_message(sid, 0, "note", f"Negotiation started with {setup.counterparty}. Their opening ask is {engine.fmt(setup.currency, setup.ask)}.")
    return _out(_get(sid))


@app.get("/api/sessions")
def sessions():
    return [{**_out(s), "deal": s["deal"]} for s in db.list_sessions()]


@app.get("/api/sessions/{sid}")
def session(sid: int):
    return {"session": _out(_get(sid)), "messages": db.messages(sid), "offers": db.offers(sid)}


@app.post("/api/sessions/{sid}/settings")
def settings(sid: int, body: Settings):
    s = _get(sid)
    if s["round"] > 0 and (body.cp_type or body.rounds_total):
        raise HTTPException(409, "Counterparty and rounds can only be changed before the first round.")
    f = {k: v for k, v in body.model_dump().items() if v is not None}
    if f.get("mode") not in (None, "assist", "autonomous"):
        raise HTTPException(422, "Mode must be assist or autonomous.")
    if f:
        db.update_session(sid, **f)
    return _out(_get(sid))


@app.post("/api/sessions/{sid}/step")
def step(sid: int):
    _get(sid)
    return _run(negotiation.step, sid)


@app.post("/api/sessions/{sid}/send")
def send(sid: int):
    _get(sid)
    return _run(negotiation.send_draft, sid)


class Reply(BaseModel):
    text: str


@app.post("/api/sessions/{sid}/reply")
def reply(sid: int, body: Reply):
    _get(sid)
    return _run(negotiation.reply_text, sid, body.text)


class Decision(BaseModel):
    action: str


@app.post("/api/sessions/{sid}/decision")
def decision(sid: int, body: Decision):
    _get(sid)
    return _run(negotiation.decide, sid, body.action)
