"""Negotiation core: offer generation with the limit guard, the round loop and deal tracking (report 3.8 - 3.10)."""
import random, re
import db, engine, llm

TOL = 0.08  # how far an LLM draft's score may be from A(t) before the offer generator adjusts it


def template_message(style, cur, price, fallback):
    p, f = engine.fmt(cur, price), engine.fmt(cur, fallback)
    if style == "collaborative":
        return f"I'd like us to find something that works for both of us. I can offer {p}, and I'm open to {f} if we can agree on terms quickly."
    if style == "competitive":
        return f"Based on what I've seen in the market, {p} is a fair number. That's my position for now."
    return f"Let's move closer to the middle. I can do {p}."


def _history(sid):
    return [{"from": m["role"], "text": m["text"]} for m in db.messages(sid) if m["role"] in ("system", "counterparty")][-6:]


def produce_offer(s, c, r, strat, A, their_last, our_last):
    sid, cur = s["id"], s["currency"]
    hint = engine.pick_price(c, r, their_last, A, our_last)
    fb = engine.fallback_price(c, hint, their_last)
    feedback = None
    for _ in range(3):
        draft = llm.negotiate({
            "domain": s["domain"], "scenario": s["name"], "context": s["context"], "counterparty": s["counterparty"],
            "currency": cur, "round": r, "total_rounds": c["T"], "strategy": strat["style"], "tone": strat["tone"],
            "their_last_offer": their_last, "our_last_offer": our_last, "suggested_price": hint, "fallback_price": fb,
            "private_walk_away_limit": c["limit"], "recent_messages": _history(sid), "feedback": feedback})
        if not draft:  # offline demo mode or API failure
            draft = {"offer": {"price": hint}, "fallback": {"price": fb}, "message": template_message(strat["style"], cur, hint, fb)}
        try:
            price = float(draft["offer"]["price"])
        except Exception:
            price = None
        message = str(draft.get("message") or "")
        ok, why = engine.guard(c, price, r, their_last, message)
        if not ok:   # limit guard rejects the draft; log it and ask the model again with the reason
            db.add_offer(sid, r, "system", price, None, strat["style"], None, A, "blocked", why)
            feedback = f"Your previous draft was rejected because {why}. Stay inside the limits and never mention them."
            continue
        S = engine.score(c, price, r, their_last)[0]
        adjusted = False
        retreat = (our_last is not None and c["dir"] * (price - our_last) < 0) or c["dir"] * (price - their_last) > 0
        if abs(S - A) > TOL or retreat:   # offer generator: move the values toward the target score
            price, adjusted = hint, True
            message = template_message(strat["style"], cur, hint, fb)
            S = engine.score(c, price, r, their_last)[0]
        try:
            fbp = float(draft["fallback"]["price"])
        except Exception:
            fbp = fb
        if adjusted or not engine.within_limit(c, fbp):
            fbp = fb
        return {"price": price, "fallback": fbp, "message": message, "score": S, "adjusted": adjusted}
    # three failures: send the safest offer, or advise walking away
    if engine.guard(c, hint, r, their_last)[0]:
        S = engine.score(c, hint, r, their_last)[0]
        return {"price": hint, "fallback": fb, "message": template_message(strat["style"], cur, hint, fb), "score": S, "adjusted": True}
    return None


def finish(sid, outcome, note, price=None):
    s = db.get_session(sid)
    c = engine.make_ctx(s)
    st = s["state"]
    saved = c["dir"] * (c["ask"] - price) if (outcome == "deal" and price is not None) else 0
    st["proposed_price"] = price
    st["draft"] = None
    db.set_deal(sid, outcome, price, saved, s["round"])
    db.add_message(sid, s["round"], "note", note)
    db.update_session(sid, status=outcome, state=st)
    return db.get_session(sid)


def step(sid):
    """Run one round: read context, pick strategy, generate + guard an offer. Autonomous mode sends it; assist mode keeps a draft."""
    s = db.get_session(sid)
    if s["status"] not in ("active", "draft"):
        raise ValueError("This negotiation is not ready for a new round.")
    c, st = engine.make_ctx(s), s["state"]
    r = s["round"] + 1
    strat = engine.pick_strategy(c, r, st.get("our_last"), st["their_last"], st.get("rho"))
    A = engine.target_score(c, r, strat["beta"], st["their_last"])
    A_acc = engine.target_score(c, r, strat["beta"], neutral=True)
    out = produce_offer(s, c, r, strat, A, st["their_last"], st.get("our_last"))
    if out is None:
        return finish(sid, "walk_away", "No offer could pass the limit guard. Walking away is recommended.")
    out.update(strategy=strat, A=A, A_acc=A_acc, round=r)
    if s["mode"] == "assist":
        st["draft"] = out
        db.update_session(sid, state=st, status="draft")
        return db.get_session(sid)
    return _send(sid, out)


def send_draft(sid):
    s = db.get_session(sid)
    if s["status"] != "draft" or not s["state"].get("draft"):
        raise ValueError("There is no draft to send.")
    return _send(sid, s["state"]["draft"])


def _send(sid, out):
    s = db.get_session(sid)
    c, st, r = engine.make_ctx(s), s["state"], out["round"]
    st.update(our_last=out["price"], A=out["A"], A_acc=out["A_acc"], strategy=out["strategy"], draft=None)
    if st.get("our_first") is None:
        st["our_first"] = out["price"]
    db.add_message(sid, r, "system", out["message"])
    db.add_offer(sid, r, "system", out["price"], out["fallback"], out["strategy"]["style"], out["score"], out["A"], "sent",
                 "adjusted toward the target score" if out["adjusted"] else "passed the limit guard")
    db.update_session(sid, round=r, state=st, status="waiting_reply")
    if s["cp_type"] == "manual":
        return db.get_session(sid)
    price, accepted = engine.sim_offer(c, st["cp"], r, out["price"], st["their_last"], st["seed"])
    return apply_reply(sid, price, accepted, engine.sim_message(s["cp_type"], s["currency"], price, accepted, r, c["T"]))


def apply_reply(sid, their_price, accepted, text):
    s = db.get_session(sid)
    if s["status"] != "waiting_reply":
        raise ValueError("No offer is waiting for a reply.")
    c, st, r = engine.make_ctx(s), s["state"], s["round"]
    our = st["our_last"]
    final = our if accepted else their_price
    ok = accepted or engine.acceptable(c, final, r, st["A_acc"], our)
    db.add_message(sid, r, "counterparty", text)
    db.add_offer(sid, r, "counterparty", final, None, None, engine.score(c, final, r, final, neutral=True)[0], st["A"], "received",
                 "meets the target score" if ok else "not acceptable yet")
    st.update(their_last=final, **engine.read_counterparty(c, st["our_first"], our, final, r))
    if ok:
        st["proposed_price"] = final
        db.update_session(sid, state=st, status="awaiting_approval")
        return db.get_session(sid)
    db.update_session(sid, state=st, status="active")
    if r >= c["T"]:
        return finish(sid, "walk_away", "The deadline passed without an offer inside your limits. Walking away is recommended.")
    return db.get_session(sid)


_NUM = re.compile(r"(\d[\d,]*(?:\.\d+)?)\s*(k|lakhs?|lacs?)?\b", re.I)


def reply_text(sid, text):
    """Manual counterparty: read their typed (or spoken) reply and apply it."""
    s = db.get_session(sid)
    if s["status"] != "waiting_reply":
        raise ValueError("No offer is waiting for a reply.")
    t = text.strip()
    nums = []
    for m in _NUM.finditer(t):
        v = float(m.group(1).replace(",", ""))
        mult = (m.group(2) or "").lower()
        v *= 1000 if mult == "k" else 100000 if mult.startswith(("lakh", "lac")) else 1
        nums.append(v)
    if nums:
        return apply_reply(sid, nums[0], False, t)
    if re.search(r"\b(deal|accept(ed)?|agreed?|done|ok(ay)?)\b", t, re.I):
        return apply_reply(sid, None, True, t)
    if re.search(r"walk away|no deal|not interested|final no", t, re.I):
        db.add_message(sid, s["round"], "counterparty", t)
        return finish(sid, "walk_away", "The counterparty ended the negotiation.")
    raise ValueError("Include their offer amount (for example '17500') or say 'deal' to accept.")


def decide(sid, action):
    s = db.get_session(sid)
    c, st = engine.make_ctx(s), s["state"]
    if action == "approve":
        if s["status"] != "awaiting_approval":
            raise ValueError("There is no deal waiting for approval.")
        return finish(sid, "deal", f"You approved the deal at {engine.fmt(s['currency'], st['proposed_price'])}.", st["proposed_price"])
    if action == "reject":
        if s["status"] != "awaiting_approval":
            raise ValueError("There is no deal waiting for approval.")
        if s["round"] >= c["T"]:
            return finish(sid, "walk_away", "You declined the final offer. Negotiation ended without a deal.")
        st["proposed_price"] = None
        db.add_message(sid, s["round"], "note", "You declined this offer. The negotiation continues.")
        db.update_session(sid, state=st, status="active")
        return db.get_session(sid)
    if action == "walk_away":
        if s["status"] in ("deal", "walk_away"):
            raise ValueError("This negotiation has already ended.")
        return finish(sid, "walk_away", "You chose to walk away.")
    raise ValueError("Unknown action.")


def new_state(c, cp_type, seed):
    return {"their_last": c["ask"], "our_last": None, "our_first": None, "A": None, "A_acc": None, "strategy": None, "rho": None, "label": None,
            "proposed_price": None, "draft": None, "seed": seed, "cp": engine.sim_params(cp_type if cp_type != "manual" else "random", c, random.Random(seed))}
