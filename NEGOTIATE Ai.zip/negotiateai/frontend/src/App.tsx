import { useEffect, useState } from 'react'
import Home from './pages/Home'
import NewNegotiation from './pages/NewNegotiation'
import Workspace from './pages/Workspace'
import History from './pages/History'
import Dashboard from './pages/Dashboard'
import About from './pages/About'

function parse() {
  const [path, qs] = location.hash.replace(/^#\/?/, '').split('?')
  const [page, id] = path.split('/')
  return { page: page || 'home', id: id ? Number(id) : undefined, q: new URLSearchParams(qs || ''), key: location.hash }
}

const LINKS: [string, string][] = [['home', 'Home'], ['new', 'New Negotiation'], ['workspace', 'Workspace'], ['history', 'History'], ['dashboard', 'Dashboard'], ['about', 'About']]

export default function App() {
  const [route, setRoute] = useState(parse())
  useEffect(() => {
    const on = () => { setRoute(parse()); window.scrollTo(0, 0) }
    window.addEventListener('hashchange', on)
    return () => window.removeEventListener('hashchange', on)
  }, [])

  const last = Number(localStorage.getItem('lastSession')) || undefined
  const page = (() => {
    switch (route.page) {
      case 'new': return <NewNegotiation key={route.key} q={route.q} />
      case 'workspace': return <Workspace id={route.id ?? last} />
      case 'history': return <History />
      case 'dashboard': return <Dashboard />
      case 'about': return <About />
      default: return <Home />
    }
  })()

  return (
    <>
      <nav className="nav">
        <div className="wrap">
          <a href="#/home" className="brand">NegotiateAI</a>
          <ul>
            {LINKS.map(([k, label]) => (
              <li key={k}><a href={`#/${k}`} className={route.page === k ? 'on' : ''}>{label}</a></li>
            ))}
            <li><a href="#/new" className="btn small" style={{ padding: '14px 22px', fontSize: '1rem' }}>Start Negotiating</a></li>
          </ul>
        </div>
      </nav>
      {page}
    </>
  )
}
