import type { Extracted, Message, Offer, Preview, Session, Setup, Stats } from './types'

async function j<T>(r: Response): Promise<T> {
  if (!r.ok) {
    let m = r.statusText
    try { const d = await r.json(); m = typeof d.detail === 'string' ? d.detail : JSON.stringify(d.detail) } catch { /* keep status text */ }
    throw new Error(m)
  }
  return r.json()
}
const post = <T,>(u: string, b?: unknown) =>
  fetch('/api' + u, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: b === undefined ? undefined : JSON.stringify(b) }).then(r => j<T>(r))
const get = <T,>(u: string) => fetch('/api' + u).then(r => j<T>(r))

const body = (s: Setup) => ({ ...s, ask: Number(s.ask), target: Number(s.target), limit: Number(s.limit) })

export const api = {
  stats: () => get<Stats>('/stats'),
  extract: (f: FormData) => fetch('/api/extract', { method: 'POST', body: f }).then(r => j<Extracted>(r)),
  preview: (s: Setup) => post<Preview>('/preview', body(s)),
  create: (s: Setup) => post<Session>('/sessions', body(s)),
  list: () => get<Session[]>('/sessions'),
  get: (id: number) => get<{ session: Session; messages: Message[]; offers: Offer[] }>(`/sessions/${id}`),
  step: (id: number) => post<Session>(`/sessions/${id}/step`),
  send: (id: number) => post<Session>(`/sessions/${id}/send`),
  reply: (id: number, text: string) => post<Session>(`/sessions/${id}/reply`, { text }),
  decide: (id: number, action: 'approve' | 'reject' | 'walk_away') => post<Session>(`/sessions/${id}/decision`, { action }),
  settings: (id: number, b: Record<string, unknown>) => post<Session>(`/sessions/${id}/settings`, b),
}

export const money = (cur: string, v: number | null | undefined) =>
  v == null ? '—' : `${cur}${Math.abs(v) >= 100 ? Math.round(v).toLocaleString('en-IN') : v.toFixed(2)}`

export const compact = (v: number) =>
  v >= 1e7 ? `₹${(v / 1e7).toFixed(1)}Cr` : v >= 1e5 ? `₹${(v / 1e5).toFixed(1)}L` : `₹${Math.round(v).toLocaleString('en-IN')}`
