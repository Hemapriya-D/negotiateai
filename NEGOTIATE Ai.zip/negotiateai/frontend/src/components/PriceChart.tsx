import type { Offer, Session } from '../types'

/** Offers per round: our offers (blue), the counterparty's (violet), with the target and walk-away limit as dashed lines. */
export default function PriceChart({ s, offers }: { s: Session; offers: Offer[] }) {
  const W = 330, H = 190, p = 30
  const ours = offers.filter(o => o.side === 'system' && o.status === 'sent' && o.price != null)
  const theirs = offers.filter(o => o.side === 'counterparty' && o.price != null)
  const vals = [s.ask, s.target, s.limit]
  const lo = Math.min(...vals), hi = Math.max(...vals)
  const x = (r: number) => p + (r / s.rounds_total) * (W - 2 * p)
  const y = (v: number) => H - p - ((v - lo) / (hi - lo || 1)) * (H - 2 * p)
  const line = (pts: [number, number][]) => pts.map(([a, b]) => `${x(a)},${y(b)}`).join(' ')
  const t = [[0, s.ask] as [number, number], ...theirs.map(o => [o.round, o.price!] as [number, number])]
  const u = ours.map(o => [o.round, o.price!] as [number, number])
  return (
    <svg className="chart" viewBox={`0 0 ${W} ${H}`} width="100%" role="img" aria-label="Offers per round">
      {[['target', s.target, '#34d399'], ['limit', s.limit, '#f87171']].map(([n, v, col]) => (
        <g key={n as string}>
          <line x1={p} x2={W - p} y1={y(v as number)} y2={y(v as number)} stroke={col as string} strokeDasharray="4 4" opacity=".6" />
          <text x={W - p} y={y(v as number) - 4} textAnchor="end">{n as string}</text>
        </g>
      ))}
      <polyline fill="none" stroke="#8b5cf6" strokeWidth="2.5" points={line(t)} />
      {u.length > 0 && <polyline fill="none" stroke="#4f7cf0" strokeWidth="2.5" points={line(u)} />}
      {t.map(([a, b], i) => <circle key={'t' + i} cx={x(a)} cy={y(b)} r="3.5" fill="#8b5cf6" />)}
      {u.map(([a, b], i) => <circle key={'u' + i} cx={x(a)} cy={y(b)} r="3.5" fill="#4f7cf0" />)}
      {Array.from({ length: s.rounds_total + 1 }, (_, r) => <text key={r} x={x(r)} y={H - 8} textAnchor="middle">{r}</text>)}
    </svg>
  )
}
