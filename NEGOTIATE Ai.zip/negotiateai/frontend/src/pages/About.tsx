export default function About() {
  return (
    <div className="wrap" style={{ paddingBottom: 80 }}>
      <div className="page-title"><h2>About NegotiateAI</h2></div>
      <div className="prose">
        <p>NegotiateAI is a unified multimodal AI system for automated negotiation. Pricing, vendor, hiring, retention and custom scenarios all run on one shared engine, so a new domain is only a set of issues, weights and limits.</p>
        <h3>How each round works</h3>
        <ul>
          <li><b>Strategy picker:</b> chooses a collaborative, compromise or competitive style from four signals and may switch every round.</li>
          <li><b>Offer scoring:</b> offers are compared on cost, time, relationship and safety, not on price alone.</li>
          <li><b>Concession pace:</b> a time-dependent target score decides how fast the AI yields.</li>
          <li><b>Limit guard:</b> ordinary code, outside the language model, rejects any draft beyond your walk-away limit or that reveals it.</li>
          <li><b>You decide:</b> a deal is closed only after you approve it.</li>
        </ul>
        <h3>Multimodal input</h3>
        <p>Type, speak, or upload a quotation, offer letter or screenshot. Gemini reads it and fills the form. Unclear values are marked for you to confirm; the model does not guess.</p>
        <h3>Prototype stack</h3>
        <table>
          <tbody>
            <tr><th>Frontend</th><td>React, TypeScript, Vite</td></tr>
            <tr><th>Backend</th><td>Python, FastAPI (REST API)</td></tr>
            <tr><th>AI model</th><td>Gemini API</td></tr>
            <tr><th>Storage</th><td>SQLite (sessions, messages, offers, deals)</td></tr>
            <tr><th>Deployment</th><td>Local</td></tr>
          </tbody>
        </table>
        <h3>Status</h3>
        <p>This is the design-stage prototype from the project report. Evaluation against simulated counterparties is planned for the next phase, and the strategy rules and β values are starting points, not tuned results.</p>
      </div>
    </div>
  )
}
