import { useEffect, useState } from 'react'
import { api, compact } from '../api'
import type { Stats } from '../types'

export default function Dashboard() {
  const [s, setS] = useState<Stats | null>(null)
  useEffect(() => { api.stats().then(setS).catch(() => setS(null)) }, [])
  if (!s) return <div className="wrap"><div className="page-title"><h2>Dashboard</h2></div><p className="muted">Loading… make sure the backend is running on port 8000.</p></div>
  const max = Math.max(1, ...s.by_domain.map(d => d.n))
  return (
    <div className="wrap" style={{ paddingBottom: 80 }}>
      <div className="page-title"><h2>Dashboard</h2></div>
      <div className="kpis">
        <div className="kpi"><b>{s.sessions}</b><span>Negotiations</span></div>
        <div className="kpi"><b>{s.deals_closed}</b><span>Deals closed</span></div>
        <div className="kpi"><b>{s.success_rate}%</b><span>Success rate</span></div>
        <div className="kpi"><b>{s.avg_rounds ? s.avg_rounds.toFixed(1) : '–'}</b><span>Avg rounds to a deal</span></div>
        <div className="kpi"><b>{compact(s.value_negotiated)}</b><span>Value negotiated</span></div>
        <div className="kpi"><b>{compact(s.total_saved)}</b><span>Saved vs. opening asks</span></div>
        <div className="kpi"><b>{s.blocked_drafts}</b><span>Drafts blocked by the limit guard</span></div>
        <div className="kpi"><b>{s.walk_aways}</b><span>Walk-aways</span></div>
      </div>
      <div className="box" style={{ maxWidth: 640 }}>
        <h3>Negotiations by domain</h3>
        {s.by_domain.length === 0 && <p className="muted">Nothing yet.</p>}
        <div className="bars">{s.by_domain.map(d => <div className="bar" key={d.domain}><span>{d.domain}</span><div><i style={{ width: `${(d.n / max) * 100}%` }} /></div><span>{d.n}</span></div>)}</div>
      </div>
      <p className="muted" style={{ marginTop: 18 }}>AI engine: {s.ai === 'gemini' ? 'Gemini API connected' : 'offline demo mode (set GEMINI_API_KEY to use Gemini)'}.</p>
    </div>
  )
}
