import { useEffect, useState } from 'react'
import { api, money } from '../api'
import type { Session } from '../types'

export default function History() {
  const [list, setList] = useState<Session[] | null>(null)
  useEffect(() => { api.list().then(setList).catch(() => setList([])) }, [])
  return (
    <div className="wrap">
      <div className="page-title"><h2>History</h2></div>
      {list && list.length === 0 && <p className="muted" style={{ marginTop: 24 }}>No negotiations yet. <a href="#/new" style={{ color: '#6d9bff' }}>Start one</a>.</p>}
      <div className="list">
        {list?.map(s => (
          <a className="item" key={s.id} href={`#/workspace/${s.id}`} onClick={() => localStorage.setItem('lastSession', String(s.id))}>
            <div><b>{s.name}</b><div className="muted">with {s.counterparty}</div></div>
            <span className="muted">{s.domain}</span>
            <span className={'status ' + s.status} style={{ justifySelf: 'start' }}>{s.status.replace('_', ' ')}</span>
            <span>{s.round}/{s.rounds_total} rounds</span>
            <span>{s.deal?.outcome === 'deal' ? money(s.currency, s.deal.price) : '—'}</span>
          </a>
        ))}
      </div>
    </div>
  )
}
