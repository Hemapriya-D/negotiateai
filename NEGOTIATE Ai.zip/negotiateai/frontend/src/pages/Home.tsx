import { useEffect, useState } from 'react'
import { api, compact } from '../api'
import type { Stats } from '../types'

const DOMAINS = [
  ['pricing', '💰', 'Pricing', 'Negotiate product & service pricing with precision'],
  ['vendor', '🤝', 'Vendor', 'Secure the best vendor contracts and partnerships'],
  ['hiring', '💼', 'Hiring', 'Optimize salary packages and employment terms'],
  ['retention', '🔄', 'Retention', 'Retain top talent with data-driven counteroffers'],
  ['custom', '🛠️', 'Custom Builder', 'Build any negotiation scenario with full control'],
]
const STEPS = [
  ['1. Input', 'Text, voice, images or documents.'], ['2. Strategy', 'AI selects the best strategy automatically.'],
  ['3. Offer', 'AI makes an opening offer within your limits.'], ['4. Rounds', 'Offer, counter-offer, response.'], ['5. Outcome', 'Deal reached or walk away.'],
]
const FEATURES = [
  ['🧠', 'Shared AI Engine', 'Every domain runs on one intelligent core.'],
  ['⚡', 'Real-Time Analysis', 'Counterparty reading, offer scoring and strategy switching in every round.'],
  ['🎯', 'Walk-Away Limits', 'The AI never recommends exceeding your limit.'],
  ['🎙️', 'Multimodal', 'Voice, image and document inputs.'],
]

export default function Home() {
  const [st, setSt] = useState<Stats | null>(null)
  useEffect(() => { api.stats().then(setSt).catch(() => setSt(null)) }, [])
  return (
    <>
      <header className="hero">
        <div className="wrap">
          <span className="pill">One AI engine. Five negotiation domains.</span>
          <h1>Negotiate smarter.<br /><span>Decide better.</span></h1>
          <p>NegotiateAI analyzes offers, picks the best strategy for your situation, and negotiates round by round until the counterparty says deal or walk away.</p>
          <div className="cta">
            <a className="btn" href="#/new">Start New Negotiation</a>
            <a className="btn ghost" href="#/new?demo=1">View Demo</a>
          </div>
          <div className="stats">
            <div><b>{st ? st.deals_closed : '–'}</b><small>Deals Closed</small></div>
            <div><b>{st ? compact(st.value_negotiated) : '–'}</b><small>Value Negotiated</small></div>
            <div><b>{st ? `${st.success_rate}%` : '–'}</b><small>Success Rate</small></div>
          </div>
          <div className="note-line">Live numbers from your own negotiations on this device.</div>
        </div>
      </header>

      <section className="block">
        <div className="wrap">
          <h2>Five Domains. One Engine.</h2>
          <p className="sub">Choose your negotiation type. The AI adapts instantly.</p>
          <div className="cards">
            {DOMAINS.map(([id, ic, t, d]) => (
              <div className="card" key={id}>
                <div className="ic">{ic}</div><h3>{t}</h3><p>{d}</p>
                <a className="go" href={`#/new?domain=${id}`}>Start →</a>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="block">
        <div className="wrap">
          <h2>How It Works</h2>
          <div className="cards">{STEPS.map(([t, d]) => <div className="card step" key={t}><h3>{t}</h3><p>{d}</p></div>)}</div>
        </div>
      </section>

      <section className="block">
        <div className="wrap">
          <h2>Built Different</h2>
          <div className="cards">
            {FEATURES.map(([ic, t, d]) => <div className="card" key={t}><div className="ic">{ic}</div><h3>{t}</h3><p>{d}</p></div>)}
          </div>
        </div>
      </section>
    </>
  )
}
