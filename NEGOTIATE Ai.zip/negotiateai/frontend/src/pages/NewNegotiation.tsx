import { useEffect, useRef, useState } from 'react'
import { api, money } from '../api'
import { listen, speechSupported } from '../speech'
import type { DomainId, Preview, Setup } from '../types'

const DOMAINS: [DomainId, string][] = [['pricing', 'Pricing'], ['vendor', 'Vendor'], ['hiring', 'Hiring'], ['retention', 'Retention'], ['custom', 'Custom Builder']]
const WEIGHT_NAMES = { c: 'Cost', t: 'Time', r: 'Relationship', s: 'Safety' } as const

const DEMO: Setup = {
  name: 'House Rent Negotiation', domain: 'custom', counterparty: 'Landlord', currency: '₹', rounds_total: 6, mode: 'autonomous', cp_type: 'stubborn',
  context: 'Landlord is asking ₹22,000/month for a 2BHK apartment. Market rate is ₹16,000–₹18,000. I want to negotiate to ₹15,000.',
  ask: 22000, target: 15000, limit: 18000,
}

export default function NewNegotiation({ q }: { q: URLSearchParams }) {
  const [f, setF] = useState<Setup>(() => q.get('demo') ? DEMO : {
    name: '', domain: (q.get('domain') as DomainId) || 'pricing', context: '', counterparty: '', ask: '', target: '', limit: '',
    currency: '₹', rounds_total: 6, mode: 'autonomous', cp_type: 'stubborn',
  })
  const [pv, setPv] = useState<Preview | null>(null)
  const [pvErr, setPvErr] = useState('')
  const [files, setFiles] = useState<File[]>([])
  const [unc, setUnc] = useState<string[]>([])
  const [busy, setBusy] = useState(false)
  const [info, setInfo] = useState('')
  const [err, setErr] = useState('')
  const [rec, setRec] = useState(false)
  const stop = useRef<(() => void) | null>(null)
  const imgRef = useRef<HTMLInputElement>(null)
  const docRef = useRef<HTMLInputElement>(null)

  const set = <K extends keyof Setup>(k: K, v: Setup[K], flag?: string) => {
    setF(p => ({ ...p, [k]: v }))
    if (flag) setUnc(u => u.filter(x => x !== flag))
  }
  const num = (v: string) => (v === '' ? '' : Number(v))
  const ready = f.ask !== '' && f.target !== '' && f.limit !== ''

  useEffect(() => {   // the AI picks the opening strategy as soon as the numbers are filled in
    if (!ready) { setPv(null); setPvErr(''); return }
    const t = setTimeout(() => api.preview(f).then(p => { setPv(p); setPvErr('') }).catch(e => { setPv(null); setPvErr(e.message) }), 350)
    return () => clearTimeout(t)
  }, [f.ask, f.target, f.limit, f.domain, f.rounds_total]) // eslint-disable-line react-hooks/exhaustive-deps

  const voice = () => {
    if (rec) { stop.current?.(); return }
    const s = listen(t => setF(p => ({ ...p, context: (p.context + ' ' + t).trim() })), () => setRec(false))
    if (!s) { setErr('Voice input is not supported in this browser. Try Chrome or Edge.'); return }
    stop.current = s; setRec(true); setErr('')
  }

  const autofill = async () => {
    setBusy(true); setErr(''); setInfo('')
    try {
      const fd = new FormData()
      fd.append('text', [f.name, f.context].filter(Boolean).join('\n'))
      fd.append('domain', f.domain)
      files.forEach(x => fd.append('files', x))
      const r = await api.extract(fd)
      setF(p => ({
        ...p, name: r.scenario_name || p.name, context: r.context || p.context, counterparty: r.counterparty || p.counterparty,
        domain: r.domain && r.domain !== p.domain && !q.get('domain') ? r.domain : p.domain, currency: r.currency || p.currency,
        ask: r.their_opening_ask ?? p.ask, target: r.your_target ?? p.target, limit: r.walk_away_limit ?? p.limit,
      }))
      const map: Record<string, string> = { their_opening_ask: 'ask', your_target: 'target', walk_away_limit: 'limit', scenario_name: 'name', counterparty: 'counterparty' }
      setUnc((r.uncertain || []).map(k => map[k] || k))
      setInfo(r.source === 'offline'
        ? 'Gemini key not configured, so only basic number detection was used. Please check every field.'
        : (r.uncertain?.length ? 'Fields marked in yellow were unclear. Please confirm them.' : 'Filled from your inputs. Review before continuing.'))
    } catch (e: any) { setErr(e.message) } finally { setBusy(false) }
  }

  const go = async () => {
    setBusy(true); setErr('')
    try {
      const s = await api.create({ ...f, name: f.name || 'Untitled negotiation', counterparty: f.counterparty || 'Counterparty' })
      localStorage.setItem('lastSession', String(s.id))
      location.hash = `#/workspace/${s.id}`
    } catch (e: any) { setErr(e.message); setBusy(false) }
  }

  const u = (k: string) => (unc.includes(k) ? 'uncertain' : '')
  return (
    <div className="wrap">
      <div className="panel">
        <h2>Negotiation Details</h2>
        <div className="chips">{DOMAINS.map(([id, l]) => <button key={id} className={'chip' + (f.domain === id ? ' on' : '')} onClick={() => set('domain', id)}>{l}</button>)}</div>

        <label className="f">Scenario Name{unc.includes('name') && <em>please confirm</em>}</label>
        <input className={u('name')} value={f.name} onChange={e => set('name', e.target.value, 'name')} placeholder="e.g. House Rent Negotiation" />

        <label className="f">Context &amp; Background</label>
        <textarea value={f.context} onChange={e => set('context', e.target.value)} placeholder="Describe the situation, market rates and what you want." />

        <div className="row3">
          {([['ask', 'Their Opening Ask'], ['target', 'Your Target'], ['limit', 'Walk-Away Limit']] as const).map(([k, l]) => (
            <div key={k}>
              <label className="f">{l} ({f.currency}){unc.includes(k) && <em>please confirm</em>}</label>
              <input className={u(k)} type="number" min="0" value={f[k]} onChange={e => set(k, num(e.target.value) as never, k)} />
            </div>
          ))}
        </div>

        <label className="f">Counterparty{unc.includes('counterparty') && <em>please confirm</em>}</label>
        <input className={u('counterparty')} value={f.counterparty} onChange={e => set('counterparty', e.target.value, 'counterparty')} placeholder="e.g. Landlord" />

        <label className="f">Supporting Inputs (multimodal)</label>
        {files.length > 0 && <div className="files">{files.map((x, i) => <span className="chip" key={i}>{x.name} <button style={{ background: 'none', border: 0 }} onClick={() => setFiles(fs => fs.filter((_, j) => j !== i))} aria-label={`Remove ${x.name}`}>✕</button></span>)}</div>}
        <button className={'mm' + (rec ? ' rec' : '')} onClick={voice} disabled={!speechSupported()} title={speechSupported() ? '' : 'Not supported in this browser'}>🎤 {rec ? 'Listening… tap to stop' : 'Voice Input'}</button>
        <button className="mm" onClick={() => imgRef.current?.click()}>📷 Upload Image</button>
        <button className="mm" onClick={() => docRef.current?.click()}>📄 Upload Document</button>
        <button className="mm" onClick={autofill} disabled={busy}>✨ Auto-fill with AI</button>
        <input ref={imgRef} hidden type="file" accept="image/*" onChange={e => { if (e.target.files?.[0]) setFiles(fs => [...fs, e.target.files![0]]); e.target.value = '' }} />
        <input ref={docRef} hidden type="file" accept=".pdf,.txt,.csv,.md,application/pdf,text/plain" onChange={e => { if (e.target.files?.[0]) setFiles(fs => [...fs, e.target.files![0]]); e.target.value = '' }} />
        {info && <p className="muted">{info}</p>}
      </div>

      <div className="panel strategy-card" style={{ marginTop: -10 }}>
        <h2>AI Strategy Selected</h2>
        {pv ? (
          <>
            <p><span className={'tag ' + pv.strategy.style}>{pv.strategy.style}</span><span className="muted">{pv.strategy.tone}. {pv.strategy.reason}</span></p>
            <div className="kv"><span>You are the</span><b>{pv.dir === 1 ? 'buyer side (lower is better)' : 'seller side (higher is better)'}</b></div>
            <div className="kv"><span>Opening offer</span><b>{money(f.currency, pv.opening_price)}</b></div>
            <div className="kv"><span>{pv.hard_limit}</span><b>{money(f.currency, Number(f.limit))}</b></div>
            <div className="kv"><span>Target score A₀ / floor A_min</span><b>{pv.a0.toFixed(2)} / {pv.amin.toFixed(2)}</b></div>
            <div className="bars">{(Object.keys(WEIGHT_NAMES) as (keyof typeof WEIGHT_NAMES)[]).map(k => (
              <div className="bar" key={k}><span>{WEIGHT_NAMES[k]}</span><div><i style={{ width: `${pv.weights[k] * 100}%` }} /></div><span>{pv.weights[k].toFixed(2)}</span></div>
            ))}</div>
          </>
        ) : <p className="muted">{pvErr || 'Fill in the three amounts to see the strategy the AI will open with.'}</p>}
      </div>

      {err && <p className="err" style={{ maxWidth: 840, margin: '0 auto' }}>{err}</p>}
      <div className="actions"><button className="btn" disabled={!pv || busy} onClick={go}>Continue →</button></div>
    </div>
  )
}
