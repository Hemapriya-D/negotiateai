import { useEffect, useMemo, useRef, useState } from 'react'
import { api, money } from '../api'
import PriceChart from '../components/PriceChart'
import { listen, speechSupported } from '../speech'
import type { CpType, Message, Offer, Session } from '../types'

const LABEL: Record<string, string> = {
  active: 'Ready for next round', draft: 'Draft ready', waiting_reply: 'Waiting for reply',
  awaiting_approval: 'Needs your approval', deal: 'Deal closed', walk_away: 'Walked away',
}

export default function Workspace({ id }: { id?: number }) {
  const [s, setS] = useState<Session | null>(null)
  const [offers, setOffers] = useState<Offer[]>([])
  const [msgs, setMsgs] = useState<Message[]>([])
  const [running, setRunning] = useState(false)
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState('')
  const [reply, setReply] = useState('')
  const [rec, setRec] = useState(false)
  const stopRec = useRef<(() => void) | null>(null)
  const endRef = useRef<HTMLDivElement>(null)

  const load = async () => {
    if (!id) return
    const d = await api.get(id)
    setS(d.session); setOffers(d.offers); setMsgs(d.messages)
  }
  useEffect(() => { setRunning(false); setS(null); load().catch(e => setErr(e.message)) }, [id]) // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' }) }, [msgs.length])

  const act = async (fn: () => Promise<unknown>) => {
    setBusy(true); setErr('')
    try { await fn(); await load() } catch (e: any) { setErr(e.message); setRunning(false) } finally { setBusy(false) }
  }

  // Continuous negotiation: in autonomous mode the engine keeps running rounds until a deal, a walk-away or an approval step.
  useEffect(() => {
    if (!running || !s || busy) return
    if (['deal', 'walk_away', 'awaiting_approval'].includes(s.status)) { setRunning(false); return }
    if (s.mode === 'autonomous' && s.status === 'active') {
      const t = setTimeout(() => act(() => api.step(s.id)), 1500)
      return () => clearTimeout(t)
    }
  }, [running, s, busy]) // eslint-disable-line react-hooks/exhaustive-deps

  const thread = useMemo(() => {
    const items: { k: string; node: JSX.Element }[] = []
    msgs.forEach(m => {
      if (m.role === 'system') {
        offers.filter(o => o.round === m.round && o.status === 'blocked').forEach(o => items.push({
          k: 'b' + o.id, node: <div className="guard">🛡 Limit guard blocked a draft{o.price ? ` of ${money(s!.currency, o.price)}` : ''}: {o.reason}. Asking the model again.</div>,
        }))
      }
      const o = offers.find(x => x.round === m.round && x.status !== 'blocked' && ((m.role === 'system' && x.side === 'system') || (m.role === 'counterparty' && x.side === 'counterparty')))
      items.push({
        k: 'm' + m.id,
        node: m.role === 'note' ? <div className="system-note">{m.text}</div> : (
          <div className={'bubble ' + m.role}>
            <small>{m.role === 'system' ? 'NegotiateAI' : s!.counterparty} · round {m.round}</small>
            {m.text}
            {o && (
              <div className="meta">
                <span className="price">{money(s!.currency, o.price)}</span>
                {o.strategy && <span className={'tag ' + o.strategy}>{o.strategy}</span>}
                {o.fallback_price != null && o.side === 'system' && <span>fallback {money(s!.currency, o.fallback_price)}</span>}
              </div>
            )}
          </div>
        ),
      })
    })
    return items
  }, [msgs, offers, s])

  if (!id) return <div className="wrap"><div className="page-title"><h2>Workspace</h2></div><p className="muted" style={{ marginTop: 20 }}>No negotiation selected. <a href="#/new" style={{ color: '#6d9bff' }}>Start a new one</a> or open one from <a href="#/history" style={{ color: '#6d9bff' }}>History</a>.</p></div>
  if (!s) return <div className="wrap"><p className="muted" style={{ marginTop: 40 }}>{err || 'Loading…'}</p></div>

  const st = s.state
  const ended = s.status === 'deal' || s.status === 'walk_away'
  const fresh = s.round === 0
  const voice = () => {
    if (rec) { stopRec.current?.(); return }
    const stop = listen(t => setReply(r => (r + ' ' + t).trim()), () => setRec(false))
    if (!stop) { setErr('Voice input is not supported in this browser.'); return }
    stopRec.current = stop; setRec(true)
  }
  const sendReply = () => { const t = reply.trim(); if (t) act(async () => { await api.reply(s.id, t); setReply('') }) }
  const setting = (b: Record<string, unknown>) => act(() => api.settings(s.id, b))

  return (
    <div className="wrap">
      <div className="ws">
        <div className="thread">
          <div><h2 style={{ fontSize: '1.8rem' }}>{s.name}</h2><span className="muted">with {s.counterparty} · opening ask {money(s.currency, s.ask)}</span></div>
          {thread.map(i => <div key={i.k} style={{ display: 'contents' }}>{i.node}</div>)}
          {s.status === 'draft' && st.draft && (
            <div className="bubble system" style={{ border: '1px dashed var(--warn)' }}>
              <small>Draft for you to send · round {st.draft.round}</small>{st.draft.message}
              <div className="meta"><span className="price">{money(s.currency, st.draft.price)}</span><span className={'tag ' + st.draft.strategy.style}>{st.draft.strategy.style}</span></div>
            </div>
          )}
          {s.status === 'awaiting_approval' && (
            <div className="approve">
              <b>{s.counterparty} reached {money(s.currency, st.proposed_price)}</b>
              <div className="muted">This is inside your limits. A deal closes only when you approve it.</div>
              <div className="ctrl">
                <button className="btn small" disabled={busy} onClick={() => act(() => api.decide(s.id, 'approve'))}>Approve deal</button>
                <button className="btn small ghost" disabled={busy} onClick={() => act(() => api.decide(s.id, 'reject'))}>Keep negotiating</button>
              </div>
            </div>
          )}
          {ended && <div className="approve" style={{ borderColor: s.status === 'deal' ? undefined : 'rgba(248,113,113,.4)', background: s.status === 'deal' ? undefined : 'rgba(248,113,113,.06)' }}>
            <b>{s.status === 'deal' ? `Deal closed at ${money(s.currency, st.proposed_price)}` : 'Negotiation ended without a deal'}</b>
            {s.status === 'deal' && <div className="muted">You saved {money(s.currency, st.dir * (s.ask - (st.proposed_price ?? s.ask)))} compared with their opening ask.</div>}
            <div className="ctrl"><a className="btn small" href="#/new">New negotiation</a><a className="btn small ghost" href="#/history">History</a></div>
          </div>}
          {s.status === 'waiting_reply' && s.cp_type === 'manual' && (
            <div className="composer">
              <input value={reply} onChange={e => setReply(e.target.value)} onKeyDown={e => e.key === 'Enter' && sendReply()} placeholder={`Type ${s.counterparty}'s reply, e.g. "I can do 19,500"`} />
              <button className={'btn small ghost' + (rec ? ' rec' : '')} onClick={voice} disabled={!speechSupported()} aria-label="Voice input">🎤</button>
              <button className="btn small" disabled={busy || !reply.trim()} onClick={sendReply}>Send</button>
            </div>
          )}
          <div ref={endRef} />
        </div>

        <aside className="side">
          <div className="box">
            <h3>Status</h3>
            <span className={'status ' + s.status}>{LABEL[s.status]}</span>
            <div className="kv"><span>Round</span><b>{s.round} / {s.rounds_total}</b></div>
            <div className="kv"><span>Strategy</span><b>{st.strategy ? <span className={'tag ' + st.strategy.style} style={{ margin: 0 }}>{st.strategy.style}</span> : '—'}</b></div>
            <div className="kv"><span>Target score A(t)</span><b>{st.A != null ? st.A.toFixed(2) : '—'}</b></div>
            <div className="kv"><span>Their last offer</span><b>{money(s.currency, st.their_last)}</b></div>
            <div className="kv"><span>Our last offer</span><b>{money(s.currency, st.our_last)}</b></div>
            <div className="kv"><span>Counterparty reading</span><b>{st.label ? `${st.label} (ρ ${st.rho!.toFixed(2)})` : '—'}</b></div>
            {st.strategy && <p className="muted" style={{ fontSize: '.85rem', marginBottom: 0 }}>{st.strategy.reason}</p>}
            <div className="kv"><span>Blocked by guard</span><b>{offers.filter(o => o.status === 'blocked').length}</b></div>
          </div>

          <div className="box"><h3>Offers by round</h3><PriceChart s={s} offers={offers} /></div>

          <div className="box">
            <h3>Controls</h3>
            {fresh && (
              <>
                <div className="seg">
                  {(['autonomous', 'assist'] as const).map(m => <button key={m} className={s.mode === m ? 'on' : ''} onClick={() => setting({ mode: m })}>{m === 'autonomous' ? 'Autonomous' : 'Assist'}</button>)}
                </div>
                <select className="sm" value={s.cp_type} onChange={e => setting({ cp_type: e.target.value as CpType })} aria-label="Counterparty">
                  <option value="stubborn">Simulated: stubborn</option><option value="flexible">Simulated: flexible</option>
                  <option value="random">Simulated: random</option><option value="manual">Manual: I type their replies</option>
                </select>
                <select className="sm" value={s.rounds_total} onChange={e => setting({ rounds_total: Number(e.target.value) })} aria-label="Rounds">
                  {[4, 5, 6, 8, 10].map(n => <option key={n} value={n}>{n} rounds</option>)}
                </select>
                <p className="muted" style={{ fontSize: '.85rem' }}>{s.mode === 'autonomous' ? 'The AI opens, answers counter-offers and changes strategy on its own. You approve the final deal.' : 'The AI drafts each offer and you send it.'}</p>
              </>
            )}
            <div className="ctrl" style={{ marginTop: 10 }}>
              {!ended && s.mode === 'autonomous' && (
                <button className="btn small" disabled={busy && !running} onClick={() => setRunning(r => !r)}>{running ? 'Pause' : s.round === 0 ? 'Start negotiating' : 'Resume'}</button>
              )}
              {!ended && s.mode === 'assist' && (s.status === 'active' || s.status === 'draft') && (
                <button className="btn small ghost" disabled={busy} onClick={() => act(() => api.step(s.id))}>{s.status === 'draft' ? 'Redraft' : 'Draft next offer'}</button>
              )}
              {s.status === 'draft' && <button className="btn small" disabled={busy} onClick={() => act(() => api.send(s.id))}>Send offer</button>}
              {s.mode === 'autonomous' && s.status === 'active' && !running && s.round > 0 && <button className="btn small ghost" disabled={busy} onClick={() => act(() => api.step(s.id))}>One round</button>}
              {!ended && <button className="btn small danger" disabled={busy} onClick={() => act(() => api.decide(s.id, 'walk_away'))}>Walk away</button>}
            </div>
            {err && <p className="err">{err}</p>}
          </div>
        </aside>
      </div>
    </div>
  )
}
