/** Voice input through the browser's built-in speech recognition (no extra library). */
type Rec = { lang: string; interimResults: boolean; onresult: (e: any) => void; onend: () => void; onerror: () => void; start(): void; stop(): void }

export const speechSupported = () => !!((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition)

export function listen(onText: (t: string) => void, onEnd: () => void): (() => void) | null {
  const Ctor = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition
  if (!Ctor) return null
  const r: Rec = new Ctor()
  r.lang = 'en-IN'
  r.interimResults = false
  r.onresult = e => onText(Array.from(e.results as ArrayLike<any>).map(x => x[0].transcript).join(' '))
  r.onend = onEnd
  r.onerror = onEnd
  r.start()
  return () => r.stop()
}
