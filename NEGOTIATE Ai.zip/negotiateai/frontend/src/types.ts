export type DomainId = 'pricing' | 'vendor' | 'hiring' | 'retention' | 'custom'
export type Status = 'active' | 'draft' | 'waiting_reply' | 'awaiting_approval' | 'deal' | 'walk_away'
export type CpType = 'stubborn' | 'flexible' | 'random' | 'manual'

export interface Setup {
  name: string; domain: DomainId; context: string; counterparty: string
  ask: number | ''; target: number | ''; limit: number | ''
  currency: string; rounds_total: number; mode: 'assist' | 'autonomous'; cp_type: CpType
}
export interface Strategy { style: 'collaborative' | 'compromise' | 'competitive'; beta: number; tone: string; reason: string }
export interface Draft { price: number; fallback: number; message: string; strategy: Strategy; round: number }
export interface SessionState {
  their_last: number; our_last: number | null; A: number | null; strategy: Strategy | null
  rho: number | null; label: string | null; proposed_price: number | null; draft: Draft | null
  amin: number; a0: number; dir: 1 | -1
}
export interface Session {
  id: number; name: string; domain: DomainId; context: string; counterparty: string; currency: string
  ask: number; target: number; limit: number; rounds_total: number; mode: 'assist' | 'autonomous'; cp_type: CpType
  weights: Record<'c' | 't' | 'r' | 's', number>; status: Status; round: number; created_at: number
  state: SessionState; deal?: { outcome: string; price: number; saved: number; rounds: number } | null
}
export interface Offer {
  id: number; round: number; side: 'system' | 'counterparty'; price: number | null; fallback_price: number | null
  strategy: string | null; score: number | null; target_score: number | null; status: 'sent' | 'blocked' | 'received'; reason: string
}
export interface Message { id: number; round: number; role: 'system' | 'counterparty' | 'note'; text: string }
export interface Preview {
  strategy: Strategy; opening_price: number; a0: number; amin: number; dir: 1 | -1
  weights: Record<'c' | 't' | 'r' | 's', number>; hard_limit: string
}
export interface Stats {
  sessions: number; deals_closed: number; walk_aways: number; value_negotiated: number; total_saved: number
  avg_rounds: number; success_rate: number; blocked_drafts: number; by_domain: { domain: string; n: number }[]; ai: string
}
export interface Extracted {
  scenario_name?: string | null; domain?: DomainId; context?: string | null; counterparty?: string | null
  their_opening_ask?: number | null; your_target?: number | null; walk_away_limit?: number | null
  currency?: string; uncertain?: string[]; source?: string
}
